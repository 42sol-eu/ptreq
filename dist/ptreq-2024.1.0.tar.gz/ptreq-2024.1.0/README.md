# PTREQ - Pure Text Requirements

## Experimental Project to create text-based requirements for software projects

This project is an experiment to create a text-based requirements system for software projects. The idea is to create a simple, easy to use, and easy to understand system that can be used to create and manage requirements for software projects.
